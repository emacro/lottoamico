/**
 * 
 */
package it.emacro.extractor;

/**
 * @author Emc
 *
 */
public interface Constants {
	
	public static final int TUTTE 		= 0;
	public static final int BARI  		= 1;
	public static final int CAGLIARI	= 2; 
	public static final int FIRENZE		= 3;  
	public static final int GENOVA		= 4;   
	public static final int MILANO		= 5;   
	public static final int NAPOLI		= 6;   
	public static final int PALERMO		= 7;  
	public static final int ROMA		= 8;     
	public static final int TORINO		= 9;   
	public static final int VENEZIA		= 10;  
	public static final int NAZIONALE	= 11;

}
