/**
 * 
 */
package it.emacro.extractor.util;

/**
 * @author Emc
 *
 */
public class Utils {

	private Utils() {
		super();
	}
	
	public static void println(String s){
		System.out.println(s);
	}

}
