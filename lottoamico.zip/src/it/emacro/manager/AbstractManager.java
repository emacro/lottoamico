/**
 * 
 */
package it.emacro.manager;

/**
 * @author Emc
 *
 */
public abstract class AbstractManager {

	/**
	 * 
	 */
	public AbstractManager() {
		super();
	}

}
