/**
 * 
 */
package it.emacro.distances;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

/**
 * @author user
 *
 */
public class ResultShower extends JFrame implements ActionListener {

	/**
	 * 
	 */
	public ResultShower() {
		// TODO Auto-generated constructor stub
	}

	// @Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
