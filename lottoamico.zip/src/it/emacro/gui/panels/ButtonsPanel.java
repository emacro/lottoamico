/**
 * 
 */
package it.emacro.gui.panels;

import java.awt.FlowLayout;

import javax.swing.JPanel;

/**
 * @author Emc
 * 
 */
@SuppressWarnings("serial")
public class ButtonsPanel extends JPanel {

	public ButtonsPanel() {
		super();
		setLayout(new FlowLayout(FlowLayout.CENTER));
	}

}
