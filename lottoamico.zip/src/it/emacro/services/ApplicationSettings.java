package it.emacro.services;

public class ApplicationSettings {
	
	public String applicationRoot;
	public boolean startDownloadExtractionsFile, startDbLoader, setSystemLookAndFeel;

}
